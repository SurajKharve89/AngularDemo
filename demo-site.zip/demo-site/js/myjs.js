/*$(document).ready(function(){
	$('body').hide().fadeIn(1000);
});*/